class A {
    void methodA() {
        System.out.println("Method in A");
    }
}

class B extends A {
    void methodB() {
        System.out.println("Method in B");
    }
}

class C extends B {
    void methodC() {
        System.out.println("Method in C");
    }
}

public class Multi {
    public static void main(String[] args) {
        C c = new C();
        c.methodA();
        c.methodB();
        c.methodC();
    }
}
