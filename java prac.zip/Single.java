import java.util.Scanner;

class Parent {
    void parentMethod() {
        System.out.println("Parent method");
    }
}

class Child extends Parent {
    void childMethod() {
        System.out.println("Child method");
    }
}

public class Single {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Child child = new Child();
        child.parentMethod();
        child.childMethod();
        scanner.close();
    }
}
