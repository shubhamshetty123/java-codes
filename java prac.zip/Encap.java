import java.util.Scanner;

class Encap {
    private String data;

    void setData(String value) {
        data = value;
    }

    String getData() {
        return data;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Encap obj = new Encap();

        System.out.print("Enter data: ");
        obj.setData(scanner.nextLine());

        System.out.println("Data: " + obj.getData());

        scanner.close();
    }
}
