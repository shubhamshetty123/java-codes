import java.util.Scanner;

public class Wrap {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer: ");
        int num = scanner.nextInt();

        Integer wrappedNum = num; // Autoboxing

        System.out.println("Wrapped Integer: " + wrappedNum);

        int unwrappedNum = wrappedNum; // Unboxing

        System.out.println("Unwrapped Integer: " + unwrappedNum);

        scanner.close();
    }
}
